import 'package:flutter/material.dart';

class AppColors {
  static const primary = Colors.red;
  static const background = Colors.black;
}

class AppRoutes {
  static const home = '/home';
  static const details = '/details';
}

import 'package:flutter/material.dart';

final lightTheme = ThemeData.light();

final darkTheme = ThemeData.dark();

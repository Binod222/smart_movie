class LocalNetwork {
  // User Queries
  Future<void> registerUser(
      String username, String email, String password) async {}
  Future<void> deleteUser() async {}
  Future<void> getAllUsers() async {}
  Future<void> updateUser() async {}
  Future<void> loginUser(String username, String password) async {}
}

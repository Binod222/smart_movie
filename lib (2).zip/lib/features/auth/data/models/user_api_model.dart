import 'package:equatable/equatable.dart';
import 'package:json_annotation/json_annotation.dart';
import 'package:smart_movie/features/auth/domain/entity/auth_entity.dart';


@JsonSerializable()
class UserApiModel extends Equatable {
  @JsonKey(name: '_id')
  final String? userId;
  @JsonKey(name: 'name')
  final String fullName;
  final String email;
  final String password;
  

  const UserApiModel({
    this.userId,
    required this.fullName,
    required this.email,
    required this.password,
   
  });

  const UserApiModel.empty()
      : userId = '',
        fullName = '',
        email = '',
        password = '',
        

  // From JSON
  factory UserApiModel.fromJson(Map<String, dynamic> json) {
    return UserApiModel(
      userId: json['_id'],
      fullName: json['name'],
      email: json['email'],
      password: json['password'], 
    );
  }

  // To JSON
  Map<String, dynamic> toJson() {
    return {
      'name': fullName,
      'email': email,
      'password': password,
      
    };
  }

  // Convert API Object to Entity
  AuthEntity toEntity() => AuthEntity(
        userId: userId,
        userName: fullName,
        email: email,
        password: password,
        
      );

  // Convert Entity to API Object
  static UserApiModel fromEntity(AuthEntity entity) => UserApiModel(
        fullName: entity.userName,
        email: entity.email,
        password: entity.password,
        
      );

  // Convert API List to Entity List
  static List<AuthEntity> toEntityList(List<UserApiModel> models) =>
      models.map((model) => model.toEntity()).toList();

  @override
  List<Object?> get props => [
        userId,
        fullName,
        email,
        password,
        
      ];
}
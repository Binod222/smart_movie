// part of 'splashscreen_cubit.dart';

// sealed class SplashscreenState extends Equatable {
//   const SplashscreenState();

//   @override
//   List<Object> get props => [];
// }

// final class SplashscreenInitial extends SplashscreenState {}
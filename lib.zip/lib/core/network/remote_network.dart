class RemoteNetwork {}

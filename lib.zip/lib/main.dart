import 'package:flutter/material.dart';
import 'package:smart_movie/app/app.dart';

void main() {
  runApp(const MyApp());
}
